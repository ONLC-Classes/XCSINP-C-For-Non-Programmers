﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace InvoiceLineItems
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            List<Invoice> invoiceList = InvoiceDB.GetInvoices();
            List<LineItem> lineItemList = LineItemDB.GetLineItems();

            var lineItems = from lineItem in lineItemList
                            join invoice in invoiceList
                            on lineItem.InvoiceID equals invoice.InvoiceID
                            orderby invoice.InvoiceDate
                            select new
                            {
                                lineItem.InvoiceID,
                                invoice.InvoiceDate,
                                invoice.InvoiceTotal,
                                lineItem.ProductCode,
                                lineItem.UnitPrice,
                                lineItem.Quantity,
                                lineItem.ItemTotal
                            };

            int invoiceID = 0;
            int i = 0;
            foreach (var lineItem in lineItems)
            {
                if (lineItem.InvoiceID != invoiceID)
                {
                    lvLineItems.Items.Add(lineItem.InvoiceID.ToString());
                    lvLineItems.Items[i].SubItems.Add(lineItem.InvoiceDate.ToShortDateString());
                    lvLineItems.Items[i].SubItems.Add(lineItem.InvoiceTotal.ToString("c"));
                    invoiceID = lineItem.InvoiceID;
                }
                else
                {
                    lvLineItems.Items.Add("");
                    lvLineItems.Items[i].SubItems.Add("");
                    lvLineItems.Items[i].SubItems.Add("");
                }
                lvLineItems.Items[i].SubItems.Add(lineItem.ProductCode);
                lvLineItems.Items[i].SubItems.Add(lineItem.UnitPrice.ToString("c"));
                lvLineItems.Items[i].SubItems.Add(lineItem.Quantity.ToString());
                lvLineItems.Items[i].SubItems.Add(lineItem.ItemTotal.ToString("c"));
                i += 1;
            }

        }
    }
}
